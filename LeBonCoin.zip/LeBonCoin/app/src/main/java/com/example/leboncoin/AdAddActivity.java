package com.example.leboncoin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdAddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_add);
    }
}